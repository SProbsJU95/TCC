﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelasTCC.DB.Login
{
    class LoginDTO
    {
        public int Id { get; set; }

        public string Usuario { get; set; }

        public string Senha { get; set; }

        /*public void setId(int id)
        {
            this.id = id;
        }
        public int getId()
        {
            return this.id;
        }

        public void setUsuraio(String usuario)
        {
            this.usuario = usuario;
        }
        public String getUsuario()
        {
            return this.usuario;
        }

        public void setSenha(String senha)
        {
            this.senha = senha;
        }
        public String getSenha()
        {
            return this.senha;
        }*/
    }
}
